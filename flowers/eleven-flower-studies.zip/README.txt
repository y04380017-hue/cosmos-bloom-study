十一种花 · 三维开花检查集

打开 index.html 查看目录，也可直接打开各编号 HTML。每页均内嵌图片与运行依赖；核心动画可离线运行，浏览器需支持 WebGL。

建议逐项反馈：花瓣形状 / 层数 / 花心 / 花簇 / 花苞与半开 / 其他。

01. 金盏花 — 01-calendula.html
02. 花菱草(加州罂粟) — 02-california-poppy.html
03. 红亚麻 — 03-scarlet-flax.html
04. 棣棠花 — 04-kerria.html
05. 长荚罂粟 — 05-long-headed-poppy.html
06. 天人菊 — 06-blanket-flower.html
07. 天蓝绣球 — 07-phlox.html
08. 李叶绣线菊 — 08-spiraea.html
09. 宿根亚麻 — 09-blue-flax.html
10. 香石竹 — 10-carnation.html
11. 白毛岩蔷薇 — 11-rockrose.html

重要：形态依据原图，运动与隐藏结构为推定。最终相似度待用户验收。当前环境未完成 GPU 渲染验证。

原照片及署名、许可链接保留在每个页面中。Three.js MIT 许可内嵌于各 HTML。
